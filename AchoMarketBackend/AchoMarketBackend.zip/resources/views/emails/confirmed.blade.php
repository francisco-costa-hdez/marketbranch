<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
</head>
<body>
    <h1>Se ha confirmado tu cuenta de correo electrónico!</h1>
</body>
</html>