<?php

namespace App\Services\Interfaces;

interface IContactService
{
    public function createContact(array $data);
}
