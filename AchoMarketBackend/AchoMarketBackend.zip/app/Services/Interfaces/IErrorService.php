<?php

namespace App\Services\Interfaces;

interface IErrorService
{
    public function createError(array $data);
}
